const fs = require('fs');
const path = require('path');
const axios = require('axios');
const config = require('../config/netlify.json');

async function handleError(error, context) {
  try {
    console.error('Deployment error occurred:', error.message);
    
    // Log detailed error information
    const timestamp = new Date().toISOString();
    const errorDetails = {
      timestamp,
      message: error.message,
      stack: error.stack,
      context,
      deploymentId: context.deployId || 'unknown'
    };
    
    // Write to error log
    const logEntry = `${timestamp} - ERROR: ${JSON.stringify(errorDetails)}\n`;
    fs.appendFileSync(path.resolve('ai/logs/errors.log'), logEntry);
    
    // Determine if rollback is needed
    if (context.isProduction && context.previousDeployId) {
      console.log(`Attempting rollback to previous deployment: ${context.previousDeployId}`);
      
      // Implement rollback logic here
      const token = process.env[config.api.tokenEnvVar];
      const siteId = config.api.siteId;
      
      await axios.post(
        `${config.api.baseUrl}/sites/${siteId}/deploys/${context.previousDeployId}/restore`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
      
      console.log('Rollback completed successfully');
      
      // Log rollback action
      const rollbackEntry = `${timestamp} - Rolled back to deployment ${context.previousDeployId} due to error\n`;
      fs.appendFileSync(path.resolve('ai/logs/deployment.log'), rollbackEntry);
    }
    
    return true;
  } catch (rollbackError) {
    console.error('Error handling failed:', rollbackError.message);
    
    // Log the error handling failure
    const timestamp = new Date().toISOString();
    const logEntry = `${timestamp} - ERROR HANDLING FAILED: ${rollbackError.message}\n`;
    fs.appendFileSync(path.resolve('ai/logs/errors.log'), logEntry);
    
    return false;
  }
}

module.exports = handleError;
