const fs = require('fs');
const path = require('path');
const axios = require('axios');
const config = require('../config/netlify.json');

async function postDeploy(deployId) {
  try {
    // Log deployment completion
    console.log(`Deployment ${deployId} completed, running post-deployment checks`);
    
    // Get deployment information
    const token = process.env[config.api.tokenEnvVar];
    const siteId = config.api.siteId;
    
    const response = await axios.get(
      `${config.api.baseUrl}/sites/${siteId}/deploys/${deployId}`,
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );
    
    const deployment = response.data;
    
    // Verify deployment status
    if (deployment.state !== 'ready') {
      throw new Error(`Deployment not ready, current state: ${deployment.state}`);
    }
    
    // Run basic health checks on deployed site
    const siteUrl = deployment.deploy_ssl_url || deployment.deploy_url;
    const healthCheck = await axios.get(siteUrl);
    
    if (healthCheck.status !== 200) {
      throw new Error(`Site health check failed with status: ${healthCheck.status}`);
    }
    
    // Update deployment log
    const timestamp = new Date().toISOString();
    const logEntry = `${timestamp} - Deployment ${deployId} successful, site is healthy\n`;
    fs.appendFileSync(path.resolve('ai/logs/deployment.log'), logEntry);
    
    console.log('Post-deployment checks completed successfully');
    return true;
  } catch (error) {
    console.error('Post-deployment checks failed:', error.message);
    
    // Update error log
    const timestamp = new Date().toISOString();
    const logEntry = `${timestamp} - Post-deployment error: ${error.message}\n`;
    fs.appendFileSync(path.resolve('ai/logs/errors.log'), logEntry);
    
    return false;
  }
}

module.exports = postDeploy;
